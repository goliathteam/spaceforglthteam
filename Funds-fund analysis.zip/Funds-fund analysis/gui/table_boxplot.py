from ipywidgets import VBox, HBox, Label
from bqwidgets import DataGrid
import bqplot as bqp
import matplotlib
import matplotlib.pyplot as plt
import itertools

import gui.gui_utils_ryo 


class TableWithBoxPlot(VBox):
    def __init__(self):
        """
        tbls: dictionary of dataframes, the keys will turn into checkboxes, when toggled, the associated table will be loaded
        des_list, list of descriptive columns to place at the begining
        des_col_len, list of lenths for descriptive columns
        data_col_len, fixed length size for the rest of the columns, if it is not in des_list, it will asssume it is a data column
        
        """
        super().__init__()
        
    def update(self, tbls, des_list, des_col_len, data_col_len, tbl_cb=None):
        self.__tbls = tbls
        self.__des_list = des_list
        self.__des_col_len = des_col_len
        self.__data_col_len = data_col_len
        self.__tb_cb = tbl_cb
        self.__val_cols = self.__get_val_cols()
        self.__build_gui()
        self.__update(self.__get_first_tbl())
    
    
    def __get_val_cols(self):
        # grab first table in alphabetical order
        tbl = self.__get_first_tbl()
        # remove all descriptive columns
        all_cols = list(tbl.columns)
        for col in self.__des_list:
            all_cols.remove(col)
        all_cols.sort()
        return all_cols
    
    def __get_first_tbl(self):
        tbl_names = list(self.__tbls.keys())
        tbl_names.sort()
        tbl_name = tbl_names[0]
        tbl = self.__tbls[tbl_name]
        return tbl
    
    
    #**********************************************************************
    #
    #     Building the GUI
    #
    #**********************************************************************
    
    def __build_gui(self):
        #func for checkboxes
        self.cb_box = self.__build_gui_check_boxes()
        
        #table and charts 
        bottom_panel = VBox()
        
        #table
        tbl_names = list(self.__tbls.keys())
        tbl_names.sort()
        tbl_name = tbl_names[0]
        tbl = self.__tbls[tbl_name]
        defs = self.__make_col_def(tbl)
        self.tbl = DataGrid(column_defs = defs)
        
        #boxplot
        self.box_plots_panel = HBox()
        
        # events
        self.tbl.observe(self.__tbl_event_handler, 'selected_row_indices')
        
        # layouts
        width = sum(self.__des_col_len) + self.__data_col_len * len(self.__val_cols) 
        self.tbl.layout.overflow_x = 'visible'
        self.tbl.layout.width = str(width) + 'px'
        self.tbl.layout.height = '280px'
        
        self.box_plots_panel.layout.overflow_x = 'visible'
        self.box_plots_panel.layout.overflow_y = 'visible'
        
        self.box_plots_panel.layout.width = '100%'
        self.box_plots_panel.layout.max_height = '250px'
        self.box_plots_panel.layout.border = '0.5px solid white'
        self.box_plots_panel.layout.width = str(width) + 'px'

        bottom_panel.layout.overflow_x = 'scroll'
        bottom_panel.layout.overflow_y = 'hidden'
        
        self.layout.overflow_x = 'visible'
        self.layout.overflow_y = 'visible'
        
        # pack
        bottom_panel.children = [self.tbl, self.box_plots_panel]
        self.children = [self.cb_box, bottom_panel]
        
    def __build_gui_check_boxes(self):
        tables = list(self.__tbls.keys())
        cb_box = gui.gui_utils_ryo.CheckBoxSelection(tables, self.__toggle_tbl, 'abs')
        return cb_box
    
    def __build_gui_box_plots(self, width, height, x_data, y_data, name, box_color, tick_format, tick_vals=None):
        sc_x = bqp.LinearScale()
        sc_y = bqp.LinearScale()

        ax_x = bqp.Axis(label = name, 
                        scale = sc_x,
                        num_ticks = 0)

        ax_y = bqp.Axis(scale = sc_y, 
                        orientation = 'vertical', 
                        tick_format = tick_format,
                        num_ticks = 5 )
        
        if tick_vals is not None:
            ax_y.tick_values = tick_vals

        boxes = bqp.Boxplot(x = x_data, 
                            y = y_data, 
                            scales = {'x': sc_x, 'y': sc_y}, 
                            outlier_fill_color = 'white',
                            box_fill_color = box_color,
                            stroke = 'white', 
                            box_width = 25,
                            fig_margin = dict(top = 0, 
                                              bottom = 0, 
                                              left = 0, 
                                              right = 0))

        scatter_tooltip = bqp.Tooltip(fields=['name'], formats=[''], labels=[''])
        sec_marker = bqp.Scatter(x = [], 
                                 y = [], 
                                 names = [],
                                 scales = {'x': sc_x, 'y': sc_y}, 
                                 colors = [],
                                 display_names = False,
                                 tooltip = scatter_tooltip)
        
        fig = bqp.Figure(axes = [ax_x, ax_y], 
                         marks = [boxes, sec_marker], 
                         padding_x = 0.4, 
                         padding_y = 0.05)
        
        fig.fig_margin = {'top': 10,
                          'bottom': 10,
                          'left': 25,
                          'right': 5}
        fig.layout.max_width = width
        fig.layout.max_height = height
        fig.layout.min_width = width
        fig.layout.min_height = height
        fig.layout.border = '0.5px solid white'
        
        return fig
        
    def __tbl_event_handler(self, tgt):
        # get the selected rows, limit to first 5 selected
        rows_selected = tgt['new']
        if len(rows_selected) > 5:
            rows_selected = rows_selected[:5]
        # slice table by selected rows
        data_tbl = self.tbl.data.iloc[rows_selected]
        # get list of IDS
        fund_ids = data_tbl['Name'].tolist()
        # slice data columns only
        data_tbl = data_tbl[self.__get_val_cols()]
        tbl_vals = data_tbl.T.values
        # define colors
#         cmap = plt.get_cmap("Dark2")
#         color_hex = [matplotlib.colors.rgb2hex(cmap(x)[:3]) for x in range(cmap.N)]
#         color_hex = color_hex[::-1]
#         color_hex = color_hex[:len(rows_selected)]
        color_hex = ['goldenrod', 'lime', 'blueviolet', 'deeppink', 'fuchsia','Dodgerblue', 'aqua'] 
        color_hex = color_hex[:len(rows_selected)]
        
        for i, col in enumerate(tbl_vals):
            cht = self.box_plots_panel.children[i + 1] # +1 because it has a filler to offset length of ID and Name columns, 
            cht.marks[1].x = [1] * len(col)
            cht.marks[1].y = col
            cht.marks[1].colors = color_hex
            cht.marks[1].default_size = 70
            cht.marks[1].marker = 'circle'
            cht.marks[1].stroke_width = 1
            cht.marks[1].stroke = 'white'
            cht.marks[1].names = fund_ids
            
        # call second call back to update charts history
        if self.__tb_cb is not None:
            self.__tb_cb(tgt['new'], self.tbl.data)
            
    def __toggle_tbl(self, tgt=None):
        tbl_name = tgt['owner'].description
        tbl = self.__arrange_tbl(self.__tbls[tbl_name])
        self.__update(tbl)
        
    def __arrange_tbl(self, tbl):
        cols = self.__des_list + self.__val_cols
        tbl = tbl[cols]
        return tbl
    
    def __update(self, tbl):
        # update tbl
        self.tbl.data = tbl
        
        # update boxplots
        # taken from Nich's code, matplotlib, color generator
        cmap = plt.get_cmap("Dark2")
        color_hex = [matplotlib.colors.rgb2hex(cmap(x)[:3]) for x in range(cmap.N)]
        a = itertools.cycle(color_hex)

        chts = []
        cht_width = str(self.__data_col_len - 4) + 'px'
        
        # decide tick formats and values
        tbl_name = self.cb_box.get_selected_opt()
        if tbl_name == 'abs':
            tick_format = '0.2f'
            tick_vals = None
        else:
            tick_format = '0f'
            if tbl_name == 'pct':
                tick_vals = [0, 25, 50, 75, 100]
            else:
                tick_vals = self.__get_rank_labels(tbl)
                
        for val_col in self.__val_cols:
            vals = [tbl[val_col].tolist()]
            new_color = next(a)
            cht = self.__build_gui_box_plots(cht_width, '247px', [1], vals, "", new_color, tick_format, tick_vals)
            chts.append(cht)
            
        # filler - length to be equal to the descriptive fields, because those dont have boxplots
        des_len = sum(self.__des_col_len) - 4
        filler = Label()
        filler.layout.min_width = str(des_len) + "px"
        filler.layout.min_height = '297px'
        
        filler.layout.height = '100%'
        self.box_plots_panel.children = [filler] + chts
    
    def __get_rank_labels(self, tbl):
        num_rows = tbl.shape[0]
        if num_rows < 5:
            return None
        else:
            increment = num_rows / 5 
            return [0, int(increment), int(increment * 2), int(increment * 3), int(increment * 4), num_rows]
        
    def __make_col_def(self, tbl):
        column_defs = []
        for col, col_len in zip(self.__des_list, self.__des_col_len):
            col_def = {'headerName': col, 'field': col, 'width': col_len, 'pinned': 'left'}
            column_defs.append(col_def)
            
        val_cols = self.__val_cols
        for val_col in val_cols:
            col_def = {'headerName': val_col, 
                       'field': val_col, 
                       'width': self.__data_col_len, 
                       'pinned': 'left'}
            column_defs.append(col_def)
        
        return column_defs
    
    def tickers_to_names(self, tickers):
        tbl_data = self.tbl.data
        tbl_data = tbl_data[tbl_data['ID'].isin(tickers)]
        return tbl_data['Name'].tolist()
        