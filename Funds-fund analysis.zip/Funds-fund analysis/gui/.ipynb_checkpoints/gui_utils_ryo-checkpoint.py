from ipywidgets import HBox, Accordion, Button, Checkbox


class SlimAccordion(HBox):

    def __init__(self, title, children):
        """ Like an accordion, but looks like a button when not opened. """
        super().__init__()
        self._btn = self.__build_btn(title)
        self._acc = self.__build_accordion(title, children)
        self.children = [self._btn]
        self.switch()
        
    def __build_btn(self, title):
        btn = Button(description = title, button_style='success')
        btn.on_click(self.switch)
        btn.layout.overflow_x = "visible"
        return btn
    
    def __build_accordion(self, title, children):
        acc = Accordion([children])
        acc.set_title(0, title) 
        acc.layout.width = "98%"
        acc.layout.overflow_x = "visible"
        acc.observe(self.revert, names='selected_index')
        return acc
    
    def revert(self, tgt=None):
        self.children = [self._btn]
        
    def switch(self, tgt=None):
        self._acc.selected_index = 0
        self.children = [self._acc]
        
    def update_values(self, data):
        self._multiple_select.update_values(data)
        
    def read_values(self):
        return self._multiple_select.read_values()
    
    
class CheckBoxSelection(HBox):
    def __init__(self, options, cb, selected):
        """ Class to link """
        super().__init__()
        self.__cb = cb
        self.__build(options, selected)
    
    def get_selected_opt(self):
        for cb in self.children:
            if cb.value == True:
                return cb.description 
                
    def __build(self, options, selected):
        options.sort()
        cb_list = [Checkbox(description = option) for option in options]
        for cb in cb_list:
            if cb.description == selected:
                cb.value = True
            cb.observe(self.__pre_call_back, names = 'value')
        self.children = cb_list
        
    def __pre_call_back(self, tgt = None ):
        #un observe, and re-observe
        
        cb_name = tgt['owner'].description
        
        # un select all others
        for cb in self.children:
            cb.unobserve_all()
            if cb.description != cb_name:
                cb.value = False
                
        # re-observe
        for cb in self.children:
            cb.observe(self.__pre_call_back, names = 'value')
                
        # call back assigned call back
        self.__cb(tgt)
        
        
