from ipywidgets import Checkbox, HBox, VBox, Dropdown, Label, Layout, Button, HTML, Tab
from collections import OrderedDict
from functools import reduce


class SelectableOption(HBox):
    def __init__(self, val):
        """ This is a HBox containing a label, and a check box. """
        super().__init__()
        self.value = val
        self.__build_widget()
    
    def __build_widget(self):
        # CREATE WIDGETS
        self.cb_end = Checkbox(indent=False)
        box = HBox()
        self.txt = HTML('<font color=\"white\">' + self.value + '</font>')
        
        # LAYOUTS
        # check box layouts
        self.cb_end.layout.width = "20px" 
        # check box container layouts
        box.layout.justify_content = "flex-end"
        box.layout.width = "20"
        box.layout.overflow_x = "hidden"
        box.layout.overflow_y = "hidden"
        # self label layouts
        self.txt.layout.width = '80%'
        self.txt.layout.overflow_y = 'hidden'
        #self(HBox) properties
        self.__assign_self_box_properties()

        # PACK
        box.children = [self.cb_end]
        self.children = [self.txt, box]
        
    def __assign_self_box_properties(self):
        self.layout.width = "100%"
        self.layout.overflow_x = "hidden"
        self.layout.overflow_y = "hidden"
        self.layout.min_height = "27px"
        self.layout.bborder = "1px solid green"

    @property
    def check_box_val(self):
        return self.cb_end.value 
        
    @check_box_val.setter
    def check_box_val(self, x):
        self.cb_end.value = x
        
        
        
class Node(VBox):
    
    def __init__(self, name, vals, txt_len = '200px'):
        """ This a panel with a title and child options, each option can be selected. 
        The panel has the option to show / hide all options, and also select/clear all options. 
        
        name: is the header for the panel
        vals: is the values for which it creates a selectable option, if the value is a dictionary, it generates a node within a node. 
        txt_len: is used to set the max length of all text."""
        super().__init__()
        self.__assign_self_box_properties()
        self.__build_gui(name,txt_len, vals)
        
    def __assign_self_box_properties(self):
        self.layout.width = "100%"
        self.layout.overflow_x = "visible"
        self.layout.overflow_y = "visible"
        self.layout.bborder = "1px solid Red"
        
    def __build_gui(self, name, txt_len, vals):
        self.main_header = HBox(self.__make_header(name, txt_len), layout = {"min_height":"25px", 
                                                                             "overflow_x":"hidden", 
                                                                             "overflow_y":"hidden" })
        
        self.child_list = VBox(self.__build_children(vals), layout = {'width':'100%', 
                                                                      'visibility':'visible',
                                                                      "overflow_x":"visible", 
                                                                       "overflow_y":"visible", })
        self.filler = Label(value="", layout = {"width":"20%", 
                                                "overflow_x":"visible", 
                                                "overflow_y":"visible"})
        
        self.bottom_panel = HBox([self.filler, self.child_list], layout = {'width':'100%', 'height':'100%',
                                                                           "overflow_x":"visible", 
                                                                           "overflow_y":"visible", 
                                                                           "bborder":"1px solid white"})

        self.children = [self.main_header, self.bottom_panel ]
        
    #---------------------------------------------------------------------------------------
    #
    #    Build elements of gui 
    #
    #---------------------------------------------------------------------------------------    
    def __make_header(self, name, txt_len):
        txt = HTML(value='<b>' + name + '</b>', layout = {"width":txt_len, 'width':'50%'})
        self.btn_hide_show = Button(description='Hide', button_style='info',layout={'width':'55px'})
        self.btn_all_none = Button(description='All', button_style='info',layout={'width':'55px'})

        btn_box = HBox([self.btn_hide_show, self.btn_all_none], 
                       layout = {"width":"50%", 
                                 "justify_content":"flex-end", 
                                 'overflow_y':'hidden',
                                 "overflow_x":"hidden",})

        self.btn_hide_show.on_click(self.__toggle_from_button)
        self.btn_all_none.on_click(self.__select_all_from_button)
        
        return [txt, btn_box]
        
        
    def __build_children(self, vals):
        option_widgets = []
        for val in vals:
            if isinstance(val, (dict, OrderedDict)):
                for k, v in val.items():
                    widget = Node(k, v)
            else:
                widget = SelectableOption(val)
            option_widgets.append(widget)
        return option_widgets
    
    #---------------------------------------------------------------------------------------
    #
    #    Call backs for buttons in the header, for select all, unselect all, and toggle
    #
    #---------------------------------------------------------------------------------------
    
    def __toggle_from_button(self, tgt=None):
        action = self.btn_hide_show.description
        self.toggle_child_panel(action)
        
    def toggle_child_panel(self, on_off):
        if on_off == "Show":
            self.btn_hide_show.description = "Hide" 
            self.child_list.layout.visibility = "visible"
            self.child_list.layout.height = "Initial"
        else:
            self.btn_hide_show.description = "Show" 
            self.child_list.layout.visibility = "hidden"
            self.child_list.layout.height = "0px"
            
        for child in self.child_list.children:
            if isinstance(child, Node):
                child.toggle_child_panel(on_off)
            
    def __select_all_from_button(self, tgt=None):
        action = self.btn_all_none.description
        self.select_all_child(action)
    
    def select_all_child(self, all_none):
        if all_none == "All":
            self.btn_all_none.description = "Clear" 
            v = True
        else:
            self.btn_all_none.description = "All" 
            v = False
            
        for child in self.child_list.children:
            if isinstance(child, Node):
                child.select_all_child(all_none)
            else:
                child.check_box_val = v
                
    def __make_selectable_option(self, val):
        txt = Label(value = val)
        cb = Checkbox(description = val, indent=False)
        cb.layout.width = "20px" 
        return cb   
    
    def read_values(self):
        values = []
        for child in self.child_list.children:
            if isinstance(child, Node):
                child_val = child.read_values()
                if child_val is not None:
                    values = values + child_val 
            else:
                if child.check_box_val == True:
                    values.append(child.value)
        return values
    
    def write_values(self, values):
        for child in self.child_list.children:
            if isinstance(child, Node):
                child.write_values(values)
            else:
                # whether it is included, or excluded, the option has to be 
                #selected. later in the results panel it is set to exclude
                
                if 'included' in values:
                    inc_vals = values['included']
                else:
                    inc_vals = []
                    
                if 'excluded' in values:
                    exc_vals = values['excluded']
                else:
                    exc_vals = []
                all_vals = inc_vals + exc_vals

                if child.value not in all_vals:
                    child.check_box_val = False
                else:
                    child.check_box_val = True
    
    
class NestedCheckBox(VBox):
    
    def __init__(self, data, txt_len):
        """ Panel that contains all the selectable options. 
        Buttons to show/hide all options, and a list of selectable options."""
        super().__init__()
        self.__nodes = []
        self.__assign_self_box_properties()
        self.__build_nested_check_box(data, txt_len)
        
    def __assign_self_box_properties(self):
        self.layout.width = "100%"
        self.layout.overflow_x = "Visible"
        self.layout.overflow_y = "Visible"
        self.layout.bborder = "1px solid Teal"        
        self.layout.display = "block"    
        
    def __build_nested_check_box(self, data, txt_len = '200px'):
        # all widgets to be contained in this class
        children_list = []
        # these buttons expand / collapse all nodes within this widget. A node is just a group of options
        children_list.append(self.__make_buttons())
        # pass the data to Node class to create a Node. 
        for k, v in data.items():
            node = Node(k, v, txt_len)
            children_list.append(node)
            self.__nodes.append(node)
        self.children = children_list

    def __toggle_all(self, tgt=None):
        action = self.btn_hide_show.description
        for node in self.children[1:]:
            node.toggle_child_panel(action)
        if action == "Hide":
            self.btn_hide_show.description = "Show"
        else:
            self.btn_hide_show.description = "Hide"
            
    def __select_all(self, tgt=None):
        action = self.btn_all_none.description
        for node in self.children[1:]:
            node.select_all_child(action)
        if action == "All":
            self.btn_all_none.description = "Clear"
        else:
            self.btn_all_none.description = "All"       
        
    def read_values(self):
        vals = []
        for node in self.children[1:]:
            child_val = node.read_values()
            if child_val is not None:
                vals = vals + child_val
        return vals
    
    def write_values(self, values):
        # make sure that all nodes have the right selections selected. 
        for node_widget in self.__nodes:
            node_widget.write_values(values)
        
    def __make_buttons(self):
        self.btn_hide_show = Button(description='Hide', button_style='Success',layout={'width':'55px'})
        self.btn_all_none = Button(description='All', button_style='Success',layout={'width':'55px'})
        
        self.btn_hide_show.on_click(self.__toggle_all)
        self.btn_all_none.on_click(self.__select_all)
        
        btn_box = HBox([self.btn_hide_show, self.btn_all_none])
        btn_box.layout.width = "100%"
        btn_box.layout.justify_content = "flex-end"
        btn_box.layout.min_height = "30px"
        btn_box.layout.overflow_y = "hidden"
        
        return btn_box    
    
    
    
class ResultLine(HBox):
    def __init__(self, val, cb):
        """ This is a simple line with text, a dropdown with include/exclude options, and a delete button. 
        When the button is pressed the callback cb is called, to be removed."""
        super().__init__()
        self.val = val
        self.cb = cb
        self.__build_gui()
        self.__apply_self_layout()
    
    def __build_gui(self):
        # create widgets
        txt = HTML('<font color=\"white\">' + self.val + '</font>')
        self.dd = Dropdown(options=['Include', 'Exclude'])
        btn = Button(description = "x", button_style="danger")
        controls = HBox()
        
        # Formats
        txt.layout.width = "60%"
        self.__hide_overflow(txt)

        self.dd.layout.min_width = "80px"
        self.dd.layout.width = "80px"
        self.__hide_overflow(self.dd)
        
        btn.layout.min_width = "28px"
        btn.layout.width = "28px"

        controls.layout.width = "40%"
        controls.layout.justify_content = "flex-end"
        self.__hide_overflow(controls)
        
        # call backs
        btn.on_click(self.__self_remove_req)
        
        # pack 
        controls.children = [self.dd, btn]
        self.children = [txt, controls]
        
    def __hide_overflow(self, widget):
        widget.layout.overflow_x = "hidden"
        widget.layout.overflow_y = "hidden"
        
    def __apply_self_layout(self):
        self.layout.min_height = "30px"
        self.__hide_overflow(self)
        
    def __self_remove_req(self, tgt = None):
        self.cb(self.val)

    @property
    def values(self):
        pass
    
    @values.getter
    def values(self):
        return [self.val, self.dd.value]
        
        
        
class ResultsPanel(VBox):
    def __init__(self):
        """ This class represents a panel where you can push text, for each text a line is created, 
        each line has a dropdown to set to include/exclude, and delete. The class later can return 
        a list of all items with their respective selected option of include or exclude."""
        super().__init__()
        self.__apply_self_formats()
        
    #---------------------------------------------------------------------------------------
    #
    #    Create Gui
    #
    #---------------------------------------------------------------------------------------        
    
    def __apply_self_formats(self):
        self.layout.width = "100%"
        self.layout.overflow_x = "hidden"
        self.layout.overflow_y = "scroll"

    #---------------------------------------------------------------------------------------
    #
    #    Add / Remove lines
    #
    #---------------------------------------------------------------------------------------
    
    def add_line(self, values):
        new_vals = []
        for value in values:
            if self.__is_line_in_curr_list(value) == False:
                line = ResultLine(value, self.remove_line)
                new_vals.append(line)
        curr_line_list = list(self.children)
        self.children = curr_line_list + new_vals
    
    def __is_line_in_curr_list(self, value):
        curr_line_list = list(self.children)
        for line in curr_line_list:
            if line.values[0] == value:
                return True
                break
        return False
    
    def remove_line(self, value):
        curr_line_list = list(self.children)
        for line in curr_line_list:
            if line.values[0] == value:
                curr_line_list.remove(line)
                break
        self.children = curr_line_list 
                
    #---------------------------------------------------------------------------------------
    #
    #    Read values
    #
    #---------------------------------------------------------------------------------------        
    def read_values(self):
        values = []
        curr_line_list = list(self.children)
        for line in curr_line_list:
            values.append(line.values)
        return values
    
    #---------------------------------------------------------------------------------------
    #
    #    Write values
    #
    #---------------------------------------------------------------------------------------   
    def write_values(self, values):
        excluded = values['excluded']
        for res_line in self.children:
            if res_line.val in excluded:
                res_line.dd.value = 'Exclude' 
                
    #---------------------------------------------------------------------------------------
    #
    #    Clear values
    #
    #---------------------------------------------------------------------------------------        
    def clear_values(self):
        self.children = []

        
class SelectionMenu(VBox):
    def __init__(self, options, height, width, name = None, data_obj = None, cb_submit = None, cb_cancel = None):
        """ This represents a widget with 2 panels, panel 1 on the left shows the options 
        you want to display, and select. panel 2 on the right contains the options the user selects."""
        super().__init__()
        self.__cb_submit = cb_submit
        self.__cb_cancel = cb_cancel
        self.name = name
        self.data_obj = data_obj
        self.__build_gui(options, height, width)

    def __build_gui(self, options, height, width):
        # *** CREATE WIDGETS
        # left panel with selectable nested tree of selectable options
        left_panel_title = self.__build_gui_panel_name("Options")
        
        # inputs 
        self.panel_tree = NestedCheckBox(options, '100px')
        left_panel = VBox()
        
        #right panel that shows selected options 
        right_panel_title = self.__build_gui_panel_name("Selection")
        self.panel_sele = ResultsPanel()
        right_panel = VBox()
        
        # button panel with the buttons for add, clear, submit, cancel
        panel_btns = self.__build_btn_panel()
        
        #top 2 panels
        top_2_panels = HBox([])
        
        # *** LAYOUTS 
        self.panel_tree.layout.overflow_y = "Scroll"
        self.panel_tree.layout.overflow_x = "Hidden"
        self.panel_tree.layout.min_height = "525px"
        
        self.panel_sele.layout.overflow_y = "Scroll"
        self.panel_sele.layout.overflow_x = "Hidden"
        
        left_panel.layout.width = "50%"
        left_panel.layout.overflow_y = "Hidden"
        left_panel.layout.overflow_x = "Hidden"
        
        right_panel.layout.width = "50%"
        right_panel.layout.overflow_y = "Hidden"
        right_panel.layout.overflow_x = "Hidden"
        
        self_panel_height = self.__pixel_to_int(height)
        top_2_panels.layout.min_height = str(self_panel_height - 75) + "px"
        
        self.layout.height = height
        self.layout.width = width
        self.layout.border = "1px solid white"
        
        # *** Pack
        left_panel.children = [left_panel_title, self.panel_tree]
        right_panel.children = [right_panel_title, self.panel_sele]
        top_2_panels.children = [left_panel, right_panel]
        
        self.children = [top_2_panels, panel_btns]
    
    def __pixel_to_int(self, pixels):
        val = pixels.replace("px", "")
        return int(val)
        
    def __build_gui_panel_name(self, txt):
        html_val = "<center><b>" + txt + "</b></center>"
        layout = {"width":"100%", 
                 "height":"35px", 
                 "min_height":"35px", 
                 "overflow_y":"visible",
                 "border":"1px solid white"}
        panel_name = HTML(html_val)
        panel_name_box = VBox([panel_name], layout = layout)
        return panel_name_box
        
    def __build_btn_panel(self):
        # create widgets
        btn_add = Button(description="Add selected")
        btn_clear = Button(description="Clear")
        btn_submit = Button(description="Submit")
        btn_cancel = Button(description="Cancel")
        btn_panel = HBox()
        
        # call backs
        btn_add.on_click(self.__read_selected) # reads selected values and adds to summary panel
        btn_clear.on_click(self.__clear_selected) # clears all selected values
        if self.__cb_submit is not None:
            btn_submit.on_click(self.__cb_submit)
        if self.__cb_cancel is not None:
            btn_cancel.on_click(self.__cb_cancel)
        
        # layouts
        btn_panel.layout.width = "100%"
        btn_panel.layout.height = "35px"
        btn_panel.layout.min_height = "35px"
        btn_panel.layout.overflow_y = "visible"
        btn_panel.layout.overflow_x = "visible"
        btn_panel.layout.justify_content = "flex-end"
        
        # PACK
        btn_panel.children = [btn_add, btn_clear, btn_submit, btn_cancel]
        
        return btn_panel
    
    def __read_selected(self, tgt = None):
        selected_vals = self.panel_tree.read_values()
        self.panel_sele.add_line(selected_vals)
            
    def __clear_selected(self, tgt = None):
        self.panel_sele.clear_values()
        
    def read_values(self):
        return self.panel_sele.read_values()
    
    def write_values(self, values):
        """  self.panel_tree is instance of NestedCheckBox"""
        # make sure all right opions are selected
        self.panel_tree.write_values(values)
        # clear selected options
        self.__clear_selected()
        # submit
        self.__read_selected()
        # check if any excluded, and apply options
        if 'excluded' in values:
            exc_values = values['excluded']
            self.panel_sele.write_values(values)
            
        # call submit call back if available
        if self.__cb_submit is not None:
            self.__cb_submit()
            
            
class SettingsSummmary(VBox):
    def __init__(self, close_cb):
        super().__init__()
        self.__make_ui(close_cb)
        self.__selected_options = {}
        
    @property
    def options(self):
        return self.__options
        
    @options.setter
    def options(self, x):
        self.__options = x
        
    @property
    def selected_options(self):
        return self.__selected_options
    
    @selected_options.getter
    def selected_options(self):
        return self.__selected_options
    
    def __make_ui(self, close_cb): 
        # create widgets
        btn_save_close = Button(description = "Save and Close")
        btn_box = HBox()
        self.__txt_display = HTML()
        
        # apply formats
        btn_box.layout.width = "100%"
        btn_box.layout.width = "100%"
        btn_box.layout.justify_content = "flex-end"
        
        # call backs
        btn_save_close.on_click(close_cb)
        
        # pack 
        btn_box.children = [btn_save_close]
        self.children = [btn_box, self.__txt_display]
        
    def make_summary(self, tgt = None):
        html_txt = ""
        for option in self.__options:
            html_txt = html_txt + self.__get_selected_data_html(option)
        self.__txt_display.value = html_txt
    
    def __get_selected_data_html(self, option):
        selected_options =  option.read_values()
        self.__selected_options[option.name] = {}
        
        #  above is a list of list, each sub list has name and included or excluded string
        
        #s sort into selected and unselected options 
        included = []
        excluded = []
        for selected_option in selected_options:
            if selected_option[1] == 'Include':
                included.append(selected_option[0])
            else:
                excluded.append(selected_option[0])
                
        html_val = ""
        
        if (len(included) > 0) or (len(excluded) > 0):
            html_val = "<p><b><font color=white>" + option.name.upper() +"</font></b></p>"
            
        # concatenate strings
        if len(included) > 0:
            included.sort()
            self.__selected_options[option.name]['included'] = included
            html_val = html_val + "<p><b>Included: </b><font color=white>"
            for txt in included:
                html_val = html_val + txt + ", "
            html_val = html_val[:-2] + "."
            html_val = html_val + "</font></p>"
        
        if len(excluded) > 0:
            self.__selected_options[option.name]['excluded'] = excluded
            excluded.sort()
            html_val = html_val + "<p><b>Excluded: </b><font color=white>"
            for txt in excluded:
                html_val = html_val + txt + ", "
            html_val = html_val[:-2] + "."
            html_val = html_val + "</font></p>"
        
        if (len(included)>0) or (len(excluded) > 0):
            html_val = html_val + '<hr>'
        self.__selected_options[option.name]['data_obj'] = option.data_obj
        
        return html_val 
    
class MultipleSelectMenu(VBox):
    def __init__(self, btn_name, options):
        """
        options should be a list of dictionaries where:
            name is the name of the tab
            data_obj is the bq.data.x object used to filter the universe later, if theres no plan to filter, you can leave it blank. but key needs to be supplied. 
            values is the dictionary used to make the nested selection menu.
            
        **Structure of class:
        MultipleSelectMenu
            SettingsSummmary
            SelectionMenu
                NestedCheckBox
                    Node
                        SelectableOption
                ResultsPanel
                    ResultLine

        """
        
        super().__init__()
        self.options = options
        self.__btn_name = btn_name
        self.__build_gui()
        self.__toggle_tabs_panel()
        
    def __build_gui(self):
        """
        self_box
            button
            Box
                Tab
                    SelectionMenu class
                    SettingsSummary
        """
        # CREATE COMPONENTS
        if not isinstance(self.options, list):
            raise ValueError("options parameter has to be a list of dictionaries, each dictionary \
                             needs to have the keys: Name and Values, data_obj is optional ")
            
        # main button that hides / shows the menu
        self.__btn = Button(description = "Hide "+ self.__btn_name, button_style = "success")
        # tabs for each set of menu/options
        self.__tabs = Tab()
        # class that summarises all selected items, and can return selection in a dict
        self.__selection_summary = SettingsSummmary(self.__toggle_tabs_panel)
        # class to represent each selection menu  for each tab, we pass this class' function 
        # to be called when selected options are submitted to update self.__selection_summary
        # we create one for each of the dictionaries in self.options
        self.__tab_options = [SelectionMenu(opt['values'], 
                                                "600px", 
                                                "600px", 
                                                opt['name'], 
                                                opt['data_obj'], 
                                                self.__selection_summary.make_summary) 
                              for opt in self.options]
        self.__selection_summary.options = self.__tab_options
        self.__check_duplicated_tab_names()
        
        # APPLY FORMATS 
        for tab_option in self.__tab_options:
            tab_option.layout.width = "50%"
        self.__selection_summary.layout.width = "50%"
        self.layout.overflow_y = "hidden"
        self.layout.bborder = "1px solid white"
        self.__tabs.layout.bborder = "1px solid white"
        
        # CALL BACKS
        self.__btn.on_click(self.__toggle_tabs_panel)

        # PACK
        self.__populate_tabs()
        self.children = [self.__btn, self.__tabs]
    
    def __check_duplicated_tab_names(self):
        all_names = [menu_obj.name for menu_obj in self.__tab_options]
        uniq_names = set(all_names)
        dupes = [x for x in uniq_names if all_names.count(x) > 1]
        if len(dupes)>0:
            raise ValueError("Menu names must be unique.")
            
    def __populate_tabs(self):
        # for each selection menu, we create a HBox
        filler = HTML()
        filler.layout.width = "20px"
        self.__tabs.children = [HBox([tab_option, filler, self.__selection_summary]) for tab_option in self.__tab_options]
            
        # set tab name 
        for i in range(len(self.options)):
            self.__tabs.set_title(i, self.options[i]["name"])
        
    def __toggle_tabs_panel(self, tgt= None):
        if (self.__tabs.layout.height == None) or (self.__tabs.layout.height == 'initial'):
            self.__tabs.layout.height = '0px'
            self.__tabs.layout.visibility = 'hidden'
            self.__btn.description = "Show "+ self.__btn_name
        else:
            self.__tabs.layout.height = 'initial'
            self.__tabs.layout.visibility = 'visible'
            self.__btn.description = "Hide "+ self.__btn_name
            
            
    def filter_univ(self, univ, bq):
        filter_opts = self.__selection_summary.selected_options
        filtered_univ = univ
        for k, v in filter_opts.items():
            # v is a dictionary, with keys 'data_obj' and optionally keys 'included' and 'excluded'
            fld_obj = v['data_obj']
            if 'included' in v.keys():
                conds = [fld_obj == fld_obj_val for fld_obj_val in v['included']]
                cond = reduce(bq.func.or_, conds)
                filtered_univ = bq.univ.filter(filtered_univ, cond)
            if 'excluded' in v.keys():
                conds = [fld_obj != fld_obj_val for fld_obj_val in v['excluded']]
                cond = reduce(bq.func.and_, conds)
                filtered_univ = bq.univ.filter(filtered_univ, cond)
        return filtered_univ
        
    def selected_options(self):
        return self.__selection_summary.selected_options
    
    def apply_options(self, options):
        """ To apply a preset set of options to the menu. 
        could be useful when some settings need to be saved/retrieved.
        
        menu is instance of SelectionMenu
        
        """
        
        for menu in self.__tab_options:
            if menu.name in options:
                menu.write_values(options[menu.name])
            
            

        
        