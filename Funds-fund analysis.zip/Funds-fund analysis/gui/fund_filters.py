from collections import OrderedDict
import pandas as pd
import numpy as np
import datetime
from dateutil.relativedelta import relativedelta
from bqwidgets import DatePicker, TickerAutoComplete
from ipywidgets import Dropdown, Checkbox, Text, Label, HBox, VBox, Button
import bql
import gui.selection_menu
import pickle

fund_geo_focus_mapping = OrderedDict()

fund_geo_focus_mapping["Regions"] = ['African Region', 
                                    'Asian Pacific Region', 
                                    'Asian Pacific Region ex Japan', 
                                    'BRIC', 
                                    'CEE', 
                                    'Commonwealth of Independent States', 
                                    'Eastern European Region', 
                                    'EMEA', 
                                    'European Reg. ex UK', 
                                    'European Region', 
                                    'European Union', 
                                    'Eurozone', 
                                    'GCC', 
                                    'Global', 
                                    'Greater China', 
                                    'Indian Sub-Continent', 
                                    'International', 
                                    'Latin American Region', 
                                    'MENA', 
                                    'Middle East Region', 
                                    'Nordic Region', 
                                    'North American Region', 
                                    'Oceania Region', 
                                    'OECD Countries', 
                                    'South East Asia Region', 
                                    'Tiger Region', 
                                    'ASEAN Countries', 
                                    'Iberian Region']

fund_geo_focus_mapping["Western Europe"] =  ['Andorra', 
                                            'Austria', 
                                            'Belgium', 
                                            'Finland', 
                                            'Denmark', 
                                            'France', 
                                            'Germany', 
                                            'Guernsey', 
                                            'Italy', 
                                            'Spain', 
                                            'Netherlands', 
                                            'Ireland', 
                                            'Luxembourg', 
                                            'Liechtenstein', 
                                            'Malta', 
                                            'Norway', 
                                            'Portugal', 
                                            'Sweden', 
                                            'Switzerland', 
                                            'Iceland', 
                                            'U.K.']

fund_geo_focus_mapping["North America"] = ['Canada', 
                                           'U.S.', 
                                           OrderedDict([('states in the U.S.', ['Alabama State', 
                                                                                'Arizona State', 
                                                                                'Arkansas State', 
                                                                                'California State', 
                                                                                'Canada', 
                                                                                'Colorado State', 
                                                                                'Connecticut State', 
                                                                                'Florida State', 
                                                                                'Georgia State', 
                                                                                'Hawaii State', 
                                                                                'Idaho State', 
                                                                                'Kansas State', 
                                                                                'Kentucky State', 
                                                                                'Louisiana State', 
                                                                                'Maine State', 
                                                                                'Maryland State', 
                                                                                'Massachusetts State', 
                                                                                'Michigan State', 
                                                                                'Minnesota State', 
                                                                                'Mississippi State', 
                                                                                'Missouri State', 
                                                                                'Montana State', 
                                                                                'Nebraska State', 
                                                                                'New Jersey State', 
                                                                                'New Mexico State', 
                                                                                'New York State', 
                                                                                'North Carolina State', 
                                                                                'North Dakota State', 
                                                                                'Ohio State', 
                                                                                'Oklahoma State', 
                                                                                'Oregon State', 
                                                                                'Pennsylvania State', 
                                                                                'Rhode Island State', 
                                                                                'South Carolina State', 
                                                                                'Tennessee State', 
                                                                                'Texas State', 
                                                                                'Utah State', 
                                                                                'Virginia State', 
                                                                                'West Virginia State', 
                                                                                'Wisconsin State'])])]

fund_geo_focus_mapping["Asia Pacific"] = ['Australia', 
                                        'China', 
                                        'Hong Kong', 
                                        'Indonesia', 
                                        'Japan', 
                                        'Malyasia', 
                                        'Singarpore', 
                                        'Taiwan', 
                                        'Vietnam', 
                                        'Thailand', 
                                        'Macau', 
                                        'New Zealand', 
                                        'Philippines', 
                                        'South Korea']

fund_geo_focus_mapping["Eastern Europe"] = ['Bosnia And Herzegovina', 
                                            'Bulgaria', 
                                            'Cyprus', 
                                            'Greece', 
                                            'Hungary', 
                                            'Russia', 
                                            'Macedonia', 
                                            'Poland', 
                                            'Romania', 
                                            'Serbia', 
                                            'Slovenia', 
                                            'Slovakia', 
                                            'Croatia', 
                                            'Czech Republic', 
                                            'Turkey']

fund_geo_focus_mapping["Africa & Middle East"] = ['Egypt', 
                                                'South Africa', 
                                                'Israel', 
                                                'Jordan', 
                                                'Kuwait', 
                                                'Lebanon', 
                                                'Morocco', 
                                                'Mauritius', 
                                                'Namibia', 
                                                'Nigeria', 
                                                'Oman', 
                                                'Palestine', 
                                                'Qatar', 
                                                'Iraq', 
                                                'Qatar', 
                                                'Saudi Arabia', 
                                                'Turkey', 
                                                'U.A.E.']

fund_geo_focus_mapping["South & Central America"] = ['Egypt', 
                                                    'South Africa', 
                                                    'Israel', 
                                                    'Jordan', 
                                                    'Kuwait', 
                                                    'Lebanon', 
                                                    'Morocco', 
                                                    'Mauritius', 
                                                    'Namibia', 
                                                    'Nigeria', 
                                                    'Oman', 
                                                    'Palestine', 
                                                    'Qatar']

fund_geo_focus_mapping["Central Asia"] = ['Egypt', 
                                        'South Africa', 
                                        'Israel', 
                                        'Jordan']


class FundFilters(VBox):
    def __init__(self, bq):
        """ Class to generate a widget that allows you to filter a fund universe"""
        super().__init__()
        self.__bq = bq
        self.fund_enums = self.__get_fund_filter_enums()
        self.__panel = gui.selection_menu.MultipleSelectMenu("Fund Filters", self.fund_enums)
        self.children = self.__panel.children 
        self.layout.overflow_y = "hidden"
        
    #----------------------------------------------------------------------------------------
    #
    #     Get Enumerations for filters
    #
    #----------------------------------------------------------------------------------------
    
    def __get_fund_filter_enums(self):
        global fund_geo_focus_mapping
        """ Regions are static, but strategy, asset class and fund type 
        are read from request made to BQL and counting IDs per segment, to ensure it is up to date"""
        
        res = self.__get_enums_data_req()

        # fund_types
        fund_types = self.__get_fund_enum(res[0], 'FUND_TYP()')
        fund_asset = self.__get_fund_enum(res[1], 'FUND_ASSET_CLASS_FOCUS()')
        fund_strat = self.__get_fund_enum(res[2], 'FUND_STRATEGY()')

        menu_1 = OrderedDict()
        menu_1['name'] = "Fund Type:"
        menu_1['data_obj'] = self.__bq.data.FUND_TYP()
        menu_1['values'] = {"Fund Types:":fund_types}
        
        menu_2 = OrderedDict()
        menu_2['name'] = "Geographic Focus:"
        menu_2['data_obj'] = self.__bq.data.FUND_GEO_FOCUS()
        menu_2['values'] = fund_geo_focus_mapping
        
        menu_3 = OrderedDict()
        menu_3['name'] = "Fund Asset Class:"
        menu_3['data_obj'] = self.__bq.data.FUND_ASSET_CLASS_FOCUS()
        menu_3['values'] = {"Asset Class Focus:":fund_asset}

        menu_4 = OrderedDict()
        menu_4['name'] = "Fund Strategy:"
        menu_4['data_obj'] = self.__bq.data.FUND_STRATEGY()
        menu_4['values'] = {"Strategy:":fund_strat}

        menu_data = [menu_1, menu_2, menu_3, menu_4]     
        
        return menu_data
    
    def __get_enums_data_req(self):
        """ Here we get the current enumerations for some of the 
        fund fields, so we can create the menus later."""
        f = self.__bq.func
        d = self.__bq.data
        
        univ = self.__bq.univ.fundsuniv(['active', 'primary'])
        asset_class =f.count(f.group(d.id(), d.FUND_ASSET_CLASS_FOCUS()))
        strategy = f.count(f.group(d.id(), d.FUND_STRATEGY()))
        fund_type = f.count(f.group(d.id(), d.FUND_TYP()))
        flds = OrderedDict()
        flds["fund_type"] = fund_type
        flds["asset_class"] = asset_class
        flds["strategy"] = strategy
        req = bql.Request(univ, flds)
        res = self.__bq.execute(req)
        
        return res
    
    def __get_fund_enum(self, res, col_name):
        data = res.df()[col_name].tolist()
        if np.nan in data:
            data.remove(np.nan)

        if None in data:
            data.remove(None)
        data.sort()
        return data        
    
    def get_filtered_univ(self, univ):
        return self.__panel.filter_univ(univ, self.__bq)
    
    def selected_options(self):
        return self.__panel.selected_options()
    
    def apply_options(self, settings):
        self.__panel.apply_options(settings)
        
        
        
class AllFundFilters(VBox):
    
    def __init__(self, bq, FundCalculations, btn_cb):
        """ Class that creates all the inputs to filter a fund universe. 
        Also allows user to select a number of calculations for funds, and generates the data"""
        super().__init__()
        self.__widgets = {}
        self.fund_calcs = FundCalculations
        self.__build_gui(bq, btn_cb)
        self.__load_settings()
        
    def get_dts(self):
        return self.__widgets['st_dt'].value, self.__widgets['ed_dt'].value
    
    #****************************************************************
    #
    #     Build controls 
    #
    #****************************************************************    
    
    def __build_gui(self, bq, btn_cb):
        # func calc parameter inputs
        st_widgets = self.__build_st_controls()
        self.__bq = bq
        # fund filter input
        self.__widgets['fund_filter'] = FundFilters(bq)        
        # calculation selection input
        self.__widgets['output_selection'] = self.__build_output_selection_menu()
        # run all button
        btn = Button(description = "Download")
        btn.on_click(btn_cb)
        # PACK
        self.children = [st_widgets, 
                         self.__widgets['fund_filter'], 
                         self.__widgets['output_selection'], 
                         btn]
        
    def __build_output_selection_menu(self):
        menu_1 = {}
        menu_1['name'] = "Calculations:"
        menu_1['data_obj'] = None
        menu_1['values'] = {"Output:":self.fund_calcs.get_all_calc_names()}
        return gui.selection_menu.MultipleSelectMenu("Calculations: ", [menu_1])
        
    def __build_st_controls(self):
        today = datetime.datetime.today()
        ed_5y = today - relativedelta(years=3)
        
        # CREATE WIDGETS
        #start date widget
        self.__widgets['st_dt'] = DatePicker(value = ed_5y.strftime('%d-%m-%Y'), date_format = '%d-%m-%Y')
        #end date widget
        self.__widgets['ed_dt'] = DatePicker(value = today.strftime('%d-%m-%Y'), date_format = '%d-%m-%Y')
        # fx rate
        self.__widgets['fx'] = Dropdown(options=["AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "ATS", 
                                                 "AUD", "AUd", "AWG", "AZM", "AZN", "BAM", "BBD", "BDT", 
                                                 "BEF", "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BRL", 
                                                 "BRl", "BSD", "BTN", "BWP", "BWp", "BYR", "BZD", "CAD", 
                                                 "CAd", "CDF", "CHF", "CHf", "CLF", "CLP", "CNH", "CNY", 
                                                 "COP", "CRC", "CSD", "CUP", "CVE", "CYP", "CZK", "DEM", 
                                                 "DJF", "DKK", "DOP", "DZD", "ECS", "EEK", "EGP", "ERN", 
                                                 "ESP", "ETB", "EUA", "EUR", "EUr", "FIM", "FJD", "FKP", 
                                                 "FRF", "GBP", "GBp", "GEL", "GHC", "GHS", "GIP", "GMD", 
                                                 "GNF", "GRD", "GTQ", "GYD", "HKD", "HNL", "HRK", "HTG", 
                                                 "HUF", "IDR", "IEP", "IEp", "ILS", "ILs", "IMP", "INR", 
                                                 "IQD", "IRR", "ISK", "ITL", "JMD", "JOD", "JPY", "KES", 
                                                 "KGS", "KHR", "KMF", "KPW", "KRW", "KWD", "KWd", "KYD", 
                                                 "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LTL", "LUF", 
                                                 "LVL", "LYD", "MAD", "MDL", "MGA", "MGF", "MKD", "MMK", 
                                                 "MNT", "MOP", "MRO", "MTL", "MUR", "MVR", "MWK", "MWk", 
                                                 "MXN", "MYR", "MYr", "MZM", "MZN", "NAD", "NAd", "NGN", 
                                                 "NIO", "NLG", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", 
                                                 "PGK", "PHP", "PKR", "PLN", "PTE", "PYG", "QAR", "ROL", 
                                                 "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", 
                                                 "SEK", "SGD", "SGd", "SIT", "SKK", "SLL", "SOS", "SPL", 
                                                 "SRG", "SSP", "STD", "SVC", "SYP", "SZL", "SZl", "THB", 
                                                 "THO", "TJS", "TMM", "TND", "TOP", "TRL", "TRY", "TTD", 
                                                 "TWD", "TZS", "UAH", "UDI", "UGX", "USD", "USd", "UYI", 
                                                 "UYU", "UZS", "VEB", "VEF", "VND", "VUV", "WST", "XAF", 
                                                 "XAU", "XCD", "XDR", "XEU", "XOF", "XPF", "YER", "ZAR", 
                                                 "ZAr", "ZMK", "ZMW", "ZMk", "ZWD", "ZWR", "ZWd"], 
                                       value = "USD")
        # periodicity
        self.__widgets['per'] = Dropdown(options=["D", "M", "Q", "S", "W", "Y"],
                                         value = "W")
        #benchmark select
        self.__widgets['bench_select'] = TickerAutoComplete(yellow_keys=['Index'], max_results=5)
        #risk free ticker
        self.__widgets['rf_id_select'] = TickerAutoComplete(yellow_keys=['Index'], max_results=5)        
        # calculation base
        self.__widgets['base'] = Dropdown(options=["NAV_IF_AVAILABLE", "PRICE_IF_AVAILABLE"],
                                         value = "PRICE_IF_AVAILABLE")        
        # annualize
        self.__widgets['annualize'] = Checkbox(value=True)
        # annual factor
        self.__widgets['annual_factor'] = Text(value="")
        
        #labels
        lbl_txt = ['Start Date', 'End Date', 'FX', 'Periodicity', 
                   'Benchmark', 'Risk Free', 'Calculation Base', 
                   'Annualize', ' Annual Factor']
        lbl_widgets = [Label(value=txt) for txt in lbl_txt]
        
        #boxes
        lbl_row = HBox()
        ctrl_row = HBox()
        st_controls = VBox()
        
        # PACK
        lbl_row.children = lbl_widgets
        ctrl_row.children = [self.__widgets['st_dt'], 
                             self.__widgets['ed_dt'], 
                             self.__widgets['fx'],
                             self.__widgets['per'], 
                             self.__widgets['bench_select'],
                             self.__widgets['rf_id_select'],
                             self.__widgets['base'],
                             self.__widgets['annualize'],
                             self.__widgets['annual_factor']
                            ]
        
        st_controls.children = [lbl_row, ctrl_row]
        
        # LAYOUTS 
        lbl_row.layout.width = '100%'
        ctrl_row.layout.width = '100%'
        st_controls.layout.width = '100%'
        
        for widget in lbl_row.children:
            widget.layout.width = str(100 / len(lbl_row.children)) + "%"
        
        for widget in ctrl_row.children:
            widget.layout.width = str(100 / len(lbl_row.children)) + "%"
        return st_controls
    
    
    #****************************************************************
    #
    #     Save settings
    #
    #****************************************************************    
            
    def __save_settings(self):
        """get current settings from the widgets in this class, and also
        the settings in the menu class contained in this class. 
        To be called when data is downloaded. 
        Settings are saved in a pickle, and later retrieved when the class initializes. """
        # save current settings
        curr_settings = {}
        
        curr_settings['fund_filter'] = self.__widgets['fund_filter'].selected_options()
        curr_settings['ui_inputs'] = self.__get_curr_inputs()
        curr_settings['output_selection'] = self.__widgets['output_selection'].selected_options()
        # pickle settings for next time
        pickle.dump( curr_settings, open( "settings\last_settings", "wb" ) )
    
    def __get_curr_inputs(self):
        curr_inputs = {}
        curr_inputs['st_dt'] = self.__widgets['st_dt'].value
        curr_inputs['ed_dt'] = self.__widgets['ed_dt'].value
        curr_inputs['fx'] = self.__widgets['fx'].value
        curr_inputs['per'] = self.__widgets['per'].value
        curr_inputs['base'] = self.__widgets['base'].value
        curr_inputs['bench_select'] = self.__widgets['bench_select'].value
        curr_inputs['annual_factor'] = self.__widgets['annual_factor'].value
        curr_inputs['annualize'] = self.__widgets['annualize'].value
        curr_inputs['rf_id_select'] = self.__widgets['rf_id_select'].value
        
        return curr_inputs
    
    
    #****************************************************************
    #
    #     Apply saved settings
    #
    #****************************************************************    
    
    def __load_settings(self):
        """ To be called when class initializes, it applies last used settings"""
        try:
            last_settings = pickle.load( open( "settings\last_settings", "rb" ) )
            self.__apply_last_inputs(last_settings['ui_inputs'])
            self.__widgets['output_selection'].apply_options(last_settings['output_selection'])
            self.__widgets['fund_filter'].apply_options(last_settings['fund_filter'])
        except (OSError, IOError) as e:
            pass
        
    def __apply_last_inputs(self, last_inputs):
        self.__widgets['st_dt'].value = last_inputs['st_dt']
        self.__widgets['ed_dt'].value = last_inputs['ed_dt']
        self.__widgets['fx'].value = last_inputs['fx']
        self.__widgets['per'].value = last_inputs['per']
        self.__widgets['base'].value = last_inputs['base']
        self.__widgets['bench_select'].value = last_inputs['bench_select']
        self.__widgets['annual_factor'].value = last_inputs['annual_factor']
        self.__widgets['annualize'].value = last_inputs['annualize']
        self.__widgets['rf_id_select'].value = last_inputs['rf_id_select']
        
        
    #****************************************************************
    #
    #     Request data
    #
    #****************************************************************
    
    def get_data(self):
        self.__check_missing_inputs()
        self.__save_settings()
        
        # get filtered universe according to selected filters
        starting_univ = self.__bq.univ.fundsuniv(['active', 'primary'])
        filtered_univ = self.__widgets['fund_filter'].get_filtered_univ(starting_univ)
        
        # get fields 
        flds = self.__get_fields()
        
        #make request
        req = bql.Request(filtered_univ, flds)
        res = self.__bq.execute(req)
        tbl = self.__bq_res_to_pd(res)
        
        # make tables for rank, and pct rank
        tbls_dict = self.__data_to_ranks(tbl)
        return tbls_dict
    
    def __check_missing_inputs(self):
        selected_options = self.__widgets['output_selection'].selected_options()
        if 'Calculations:' not in selected_options:
            raise RuntimeError("Please select an option for filtering, and the calculations you want.")
            
        if 'included' not in selected_options['Calculations:']:
            raise RuntimeError("No calculations selected. Please select at least one calculation.")
            
        if 'Sharpe_Ratio' in selected_options['Calculations:']['included']:
            if self.__widgets['rf_id_select'].value == "":
                raise RuntimeError("Risk free ticker needed for Sharpe Ratio")
                
        if self.__widgets['bench_select'].value == "":
            raise RuntimeError("Benchmark is empty.")

    def __get_fields(self):
        selected_options = self.__widgets['output_selection'].selected_options()

        selected_calcs = selected_options['Calculations:']['included']
        fld_objects = self.fund_calcs.get_flds(selected_calcs,
                                               self.__to_bql_date(self.__widgets['st_dt'].value),
                                               self.__to_bql_date(self.__widgets['ed_dt'].value),
                                               self.__widgets['fx'].value,
                                               self.__widgets['per'].value,
                                               self.__widgets['base'].value,
                                               self.__widgets['bench_select'].value,
                                               self.__widgets['annual_factor'].value,
                                               "True" if self.__widgets['annualize'].value else "False",
                                               self.__widgets['rf_id_select'].value                                               
                                               )
        fld_objects['Name'] = self.__bq.data.name()
        return fld_objects
    
    def get_fund_calc_inputs(self):
        calc_inputs = {}
        calc_inputs['st_dt'] = self.__widgets['st_dt'].value
        calc_inputs['ed_dt'] = self.__widgets['ed_dt'].value
        calc_inputs['fx'] = self.__widgets['fx'].value
        calc_inputs['per'] = self.__widgets['per'].value
        calc_inputs['base'] = self.__widgets['base'].value
        calc_inputs['bench_select'] = self.__widgets['bench_select'].value
        calc_inputs['annual_factor'] = self.__widgets['annual_factor'].value
        calc_inputs['annualize'] = self.__widgets['annualize'].value
        calc_inputs['rf_id_select'] = self.__widgets['rf_id_select'].value
        return calc_inputs
    
    def __to_bql_date(self, dt_str):
        parts = dt_str.split("-")
        new_str = parts[2] + "-" + parts[1] + "-" + parts[0]
        return new_str

    def __bq_res_to_pd(self, res):
        tbls = []
        for r in res:
            tbl = r.df().reset_index()
            # Partial errors always appear as the last column, and they appear
            # when something went wront with the data, ie wrong ticker, or aggregation failed
            # best to error trap the error, but in this case i just ignore it
            if 'Partial Errors' in tbl.columns:
                tbl = tbl.drop(['Partial Errors'], axis=1)
            last_col_name = tbl.columns[-1] 
            tbl = tbl[['ID',last_col_name]]
            tbls.append(tbl)
        main_tbl = pd.DataFrame({'ID':tbls[0]['ID']})
        for tbl in tbls:
            main_tbl = main_tbl.merge(tbl, on='ID')
            
        return main_tbl

    
    #****************************************************************
    #
    #     get raw values and convert into rank and pct rank tables
    #
    #****************************************************************    
    
    def __data_to_ranks(self, data):
        data = self.__sort_cols(data)
        final_data = {}
        final_data['pct'] = self.__make_ranks(data, True)
        final_data['rnk'] = self.__make_ranks(data)
        final_data['abs'] = data.round(2)

        return final_data

    def __sort_cols(self, data):
        """ Take columns, start with ID and Name, order the rest alphabetically."""
        cols = self.__get_data_cols(data)
        cols.sort()
        first_cols = ['ID', 'Name']
        sorted_cols = first_cols + cols
        return data[sorted_cols]

    def __make_ranks(self, data, rank_pct=False):
        rank_tbl = data.copy()
        cols = self.__get_data_cols(rank_tbl)
        for col in cols:
            rank_mode = self.fund_calcs.get_rank_mode(col) # check if highe/lower better
            if rank_pct == False:
                rank_mode = False if rank_mode == "higher" else True # if higher is better, ascending needs to be False, so best has rank of 1
                rank_tbl[col] = rank_tbl[col].rank(method ='min', ascending = rank_mode)
            else:
                rank_mode = True if rank_mode == "higher" else False # if higher is better, ascending needs to be True, because we do rank / count
                rank_tbl[col] = self.__cust_percentile(rank_tbl[col], rank_mode)
        return rank_tbl

    def __get_data_cols(self, tbl):
        cols = list(tbl.columns)
        cols.remove('ID')
        cols.remove('Name')
        return cols

    def __cust_percentile(self, df_col, is_higher_better = True):
        """ pandas qcut doesnt like duplicate values, and 
        methodolgy doesnt set ie lowest value to 0, r highest to 100 sometimes. """
        r = df_col.rank(method ='min', ascending = is_higher_better) # min ensures that duplicate values have the equal minimum rank
        c = df_col.count() # count to exclude nan count
        df_col_percentile = ((r - 1) / (c - 1) * 100).round()
        return df_col_percentile
    
            
        
        
