from ipywidgets import VBox, HBox, Label, Dropdown, Button, HTML
from bqwidgets import DatePicker
import datetime
from dateutil.relativedelta import relativedelta
import bqplot as bqp
from IPython.display import display, clear_output
from collections import OrderedDict
import bql

class FundCharts(VBox):
    
    def __init__(self, bq, fund_filters, cb, err_display, tbl_widget):
        super().__init__()
        self.__bq = bq
        self.__fund_filters = fund_filters
        self.__fund_calcs = fund_filters.fund_calcs
        self.__cb = cb
        self.__err_display = err_display
        self.__tbl_widget = tbl_widget
        self.__widgets = {}
        self.__max_cht_num = 5
        self.__build_widgets()

        
    # ********************************************************************
    #
    #     Charting functions 
    #
    # ********************************************************************    
    
    def __build_widgets(self):
        today = datetime.datetime.today()
        ed_5y = today - relativedelta(years=1)
        avail_calcs = self.__fund_calcs.get_all_calc_names()

        # ***BUILD
        # labels 
        lbl_calc = Label(value='Calculation')
        lbl_st_dt = Label(value='Start Date')
        lbl_ed_dt = Label(value='End Date')
        lbl_per = Label(value='Periodicity')
        
        # calc select
        self.__widgets['calcs'] = Dropdown(options=avail_calcs)
        
        # start date widget
        self.__widgets['st_dt'] = DatePicker(value = ed_5y.strftime('%d-%m-%Y'), 
                                             date_format = '%d-%m-%Y')
        
        # end date widget
        self.__widgets['ed_dt'] = DatePicker(value = today.strftime('%d-%m-%Y'), 
                                             date_format = '%d-%m-%Y')
        
        # frq
        self.__widgets['per'] = Dropdown(options=["D", "M", "Q", "S", "W", "Y"],
                                         value = "W")
        # button
        self.__widgets['btn'] = Button(description = 'Download')
        
        # line chart
        self.__widgets['cht'] = self.__create_lines_chart(1) # avg, std+, std-, fund
        
        # boxes
        self.__widgets['labels'] = HBox()
        self.__widgets['controls'] = HBox()
        
        # pls wait msg 
        self.__widgets['pls_wait_msg'] = VBox([HTML(value="""<h3>Please wait.<i class="fa fa-spinner fa-spin fa-2x fa-fw" style="color:white;"></i></h3>""")])
        
        # ***PACK
        self.__widgets['controls'].children = [lbl_calc, self.__widgets['calcs'], 
                                               lbl_st_dt, self.__widgets['st_dt'], 
                                               lbl_ed_dt, self.__widgets['ed_dt'], 
                                               lbl_per, self.__widgets['per'], 
                                               self.__widgets['btn']]
                          
        self.children = [self.__widgets['controls'], 
                         self.__widgets['cht']]
        
        # ***LAYOUTS
        lbl_calc.layout.width = '5%'
        self.__widgets['calcs'].layout.width = '15%'

        lbl_st_dt.layout.width = '5%'
        self.__widgets['st_dt'].layout.width = '15%'

        lbl_ed_dt.layout.width = '5%'
        self.__widgets['ed_dt'].layout.width = '15%'

        lbl_per.layout.width = '5%'
        self.__widgets['per'].layout.width = '15%'

        self.__widgets['btn'].layout.width = '20%'
                          
        self.layout.width = '100%'
        self.layout.overflow_x = 'visible'
        self.layout.overflow_y = 'visible'

        self.__widgets['cht'].layout.width = '100%'
        self.__widgets['cht'].layout.height = '350px'
        
        self.__widgets['controls'].layout.width = '100%'
        
        self.__widgets['pls_wait_msg'].layout.height = '300px'
        
        # *** CALLBACKS
        self.__widgets['btn'].on_click(self.__cb_refresh_hist)
        
        
    # ********************************************************************
    #
    #     Charting functions 
    #
    # ********************************************************************

    def __create_lines_chart(self, num_lines):
        x_data = []
        y_data = []

        #Defining the axis types.
        self.__cht_sc_x = bqp.DateScale()
        self.__cht_sc_y = bqp.LinearScale()

        #generate list of mark objects 
        mark_list = []
        for i in range(num_lines):
            line_obj = self.__gen_line_mark([], [], 1, [''], 'solid', ['red'])
            mark_list.append(line_obj)

        #Defining axis parameters. 
        #num_ticks is useful to reduce clutter in the axiis, 
        ax_x = bqp.Axis(scale = self.__cht_sc_x, 
                        num_ticks = 5,
                        tick_format = '%m-%d-%y')

        ax_y = bqp.Axis(scale=self.__cht_sc_y, 
                        num_ticks = 5,
                        orientation = 'vertical', 
                        tick_format = '0.2f')
        
        # interaction layer
        panzoom = bqp.PanZoom(scales={'x': [ self.__cht_sc_x], 'y': [ self.__cht_sc_y]})
        
        #Assembling main canvas.
        fig = bqp.Figure(marks = mark_list, 
                         axes = [ax_x, ax_y],
                         layout = {'flex':"1", 'width':"100%"},
                         legend_location = 'right',
                         interaction = panzoom)
        fig.fig_margin = {'top': 5,
                          'bottom': 50,
                          'left': 30,
                          'right': 5}

        return fig

    def __gen_line_mark(self, x_data, y_data, width, names, style, colors):
        line = bqp.Lines(x = x_data, 
                            y = y_data, 
                            scales = {'x': self.__cht_sc_x, 'y': self.__cht_sc_y},
                            stroke_width = width, 
                            labels = names, 
                            display_legend=True, 
                            line_style = style, 
                            colors = colors)
        return line 
    
    
    # ********************************************************************
    #
    #     refresh chart
    #
    # ********************************************************************   
        
    
    def __cb_refresh_hist(self, tgt=None):
        # Function to get the fund universe, and select funds from the table
        funds, univ = self.__cb()
        
        # dont fire if nothing selected to avoid error
        if (funds is not None) and (univ is not None):
            # toggle wait msg
            self.children = [self.__widgets['controls'], 
                             self.__widgets['pls_wait_msg']]
            # to capture errors in a place, and avoid clearing the entire output.
            with self.__err_display:
                try:
                    clear_output()
                    funds = [f[0] for f in funds]
                    self.__update_chart_all(univ, funds)
                    self.children = [self.__widgets['controls'], 
                                     self.__widgets['cht'], 
                                     self.__err_display]
                except:
                    self.__err_display.layout.height = 'initial'
                    self.children = [self.__widgets['controls'], 
                                     self.__err_display]
                    raise
            
    def __update_chart_all(self, univ, funds):
        """ Downloads data, formats it and then updates the charts"""
        funds_hist, peer_hist = self.__get_data(univ, funds)
        
        # limit number of funds to max of 10
        num_funds = len(funds_hist.columns)
        if num_funds > self.__max_cht_num:
            funds_hist = funds_hist[funds_hist.columns[:self.__max_cht_num]]
            
        # update boxplots
        color_hex = ['goldenrod', 'lime', 'blueviolet', 'deeppink', 'fuchsia','Dodgerblue', 'aqua'] 
        color_hex = color_hex[:num_funds]
        
        # make funds line objects 
        x_data = bqp.traits.convert_to_date(funds_hist.index.tolist()) # index is dates, need to convert to bqplot readable dates
        y_data = funds_hist.T.values.tolist()
        fund_ids = funds_hist.columns.tolist()
        fund_names =  self.__tbl_widget.tickers_to_names(fund_ids)
        
        fund_hist_line =  self.__gen_line_mark(x_data, y_data, 0.5, fund_names, 'solid', color_hex)
        
        # make average line
        x_data = bqp.traits.convert_to_date(peer_hist.index.tolist())
        y_data = peer_hist['peers_hist_avg'].tolist()
        avg_hist_line = self.__gen_line_mark(x_data, y_data, 2, ['universe avg'], 'solid', ['aqua'])
        
        # make std lines
        y_data = peer_hist[['up', 'dn']].T.values.tolist()
        std_hist_lines = self.__gen_line_mark(x_data, y_data, 1, ['+2 stdev', '-2 stdev'], 'dotted', ['white'])
        
        # update chart
        self.__widgets['cht'].marks = [fund_hist_line, avg_hist_line, std_hist_lines]
        
        
    # ********************************************************************
    #
    #     get data
    #
    # ********************************************************************           
    def __get_data(self, universe, funds):
        # obtain field objects: fld_hist, avg_fld, std_fld
        hist_fld, hist_avg_fld, hist_std_fld = self.__get_flds()
        univ = self.__filter_univ(universe)
        request = self.__get_data_make_req(univ, funds, hist_fld, hist_avg_fld, hist_std_fld)
        print(request)
        response = self.__bq.execute(request)
        self.__check_res_err(response)
        return self.__bq_res_to_pd(response)
    
    def __filter_univ(self, univ):
        f = self.__bq.func
        
        # number of days for the calculation. 
        calc_st_dt, calc_ed_dt = self.__fund_filters.get_dts()
        days_in_calc_per = self.__calc_num_dates(calc_st_dt, calc_ed_dt)
        # start date from chart period
        st_datetime = self.__dt_str_to_datetime(self.__widgets['st_dt'].value)
        ed_datetime = self.__dt_str_to_datetime(self.__widgets['ed_dt'].value)
        # abs start date
        abs_st_dt = ed_datetime - relativedelta(days = days_in_calc_per + 10) 
        # define range function to later calculate number of available data points
        dt_rng = f.range(abs_st_dt, ed_datetime)
        # create price series to gauge history
        px = self.__bq.data.px_last(dates = dt_rng)
        # find first available date in series
        first_dt = f.first(f.dropna(px))['DATE']
        # get number of days from end date
        # dts_avail = f.today() - first_dt
        tdy_to_ed = (datetime.date.today() - ed_datetime).days
        dts_avail = f.today() - first_dt - tdy_to_ed
        # filter the universe
        filtered_univ = self.__bq.univ.filter(self.__bq.univ.list(univ), dts_avail >= days_in_calc_per)
        return filtered_univ
    
    def __get_data_make_req(self, peers, funds, hist_fld, hist_avg_fld, hist_std_fld):
        flds = OrderedDict()
        flds['fund']= hist_fld
        flds['peers_hist_avg'] = self.__bq.func.value(hist_avg_fld, peers)
        flds['peers_hist_std'] = self.__bq.func.value(hist_std_fld, peers)
        
        request = bql.Request(self.__bq.univ.list(funds), flds)    
        return request
    
    def __bq_res_to_pd(self, res):
        # funds history
        funds_hist = res[0].df().reset_index().pivot(index = "ITERATION_DATE", columns='ID', values = 'fund')
        
        # peers avg
        peers_avg = res[1].df()
        peers_avg = peers_avg[['ITERATION_DATE', 'peers_hist_avg']]
        peers_avg = peers_avg.set_index('ITERATION_DATE')
        # peers std 
        peers_std = res[2].df()
        peers_std = peers_std[['ITERATION_DATE', 'peers_hist_std']]
        peers_std = peers_std.set_index('ITERATION_DATE')
        
        tbl = peers_avg.join(peers_std, how='outer')
        
        tbl['up'] = tbl['peers_hist_avg'] + 2 * tbl['peers_hist_std'] 
        tbl['dn'] = tbl['peers_hist_avg'] - 2 * tbl['peers_hist_std'] 
        return funds_hist, tbl
        
    def __check_res_err(self, res):
        for r in res:
            tbl = r.df()
            if 'Partial Errors' in tbl.columns:
                raise ValueError("Error in chart data")
            
    def __get_flds(self):
        """ We are getting the inputs to generate a bql object that will be retrieved with rolling(). 
        Part of the inputs are within this class (the ones that decided which calc, and the period of the history).
        But others are in the AllFundFilters class, it returns  """
        # get dictionary of values 

        fund_filters = self.__fund_filters.get_fund_calc_inputs()
        num_days = self.__calc_num_dates(fund_filters['st_dt'], fund_filters['ed_dt'])
        
        requested_calc = self.__widgets['calcs'].value
        st_offset = '-' + str(num_days) + 'd'
        fx = fund_filters['fx']
        per = self.__widgets['per'].value
        base = fund_filters['base']
        bench = fund_filters['bench_select']
        annual_factor = fund_filters['annual_factor']
        annualise = "True" if fund_filters['annualize'] else "False"
        rf_id = fund_filters['rf_id_select']
        roll_st_dt = self.__dt_str_to_datetime(self.__widgets['st_dt'].value)
        roll_end_dt = self.__dt_str_to_datetime(self.__widgets['ed_dt'].value)
        roll_per = self.__widgets['per'].value
        a, b, c = self.__fund_calcs.get_hist_flds(requested_calc, 
                                                  st_offset, 
                                                  fx, 
                                                  per, 
                                                  base, 
                                                  bench, 
                                                  annual_factor, 
                                                  annualise, 
                                                  rf_id, 
                                                  roll_st_dt, 
                                                  roll_end_dt, 
                                                  roll_per)
        return a, b, c
    
    def __calc_num_dates(self, st_dt, end_dt):
        st_datetime = self.__dt_str_to_datetime(st_dt)
        ed_datetime = self.__dt_str_to_datetime(end_dt)
        return (ed_datetime - st_datetime).days
        
    def __dt_str_to_datetime(self, dt):
        parts = dt.split("-")
        d = int(parts[0])
        m = int(parts[1])
        y = int(parts[2])
        return datetime.date(y,m,d)