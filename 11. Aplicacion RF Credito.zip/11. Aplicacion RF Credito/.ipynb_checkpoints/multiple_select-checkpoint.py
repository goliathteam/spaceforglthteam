from ipywidgets import *
import numpy as np
import pandas as pd

class MultipleSelect():

    def __init__(self, button_size, button_margin, func_to_run):
        """
        This returns a VBox, with toggle buttons, and provides a method to read which buttons are selected. 
        It also comes with buttons to select all/none. And when all are selected, selecting one will clear all, 
        and mark the selected one as selected. You can pass a function to call back when 'apply' is selected

        This HBox can be put ie on a Accordion(), or used on its own to construct GUI

        ** sample usage:

        import multiple)select
        def test(tgt=None):
            print(gui.read_values())
        gui = multiple_select.MultipleSelect('200px','2.5px',test)
        df = pd.DataFrame({'test_vals':['a', 'b', 'b', 'c', 'd', 'e']})
        gui.update_values(df['test_vals'])
        panel = gui.panel
        panel

        """
        self.panel = self._make_box()
        self.btn_size = button_size
        self.btn_margin = button_margin
        self.func = func_to_run
        self.btns = []
    
    def _make_box(self):
        all_btn_panel = VBox()
        all_btn_panel.layout.overflow_y = 'auto'
        all_btn_panel.layout.overflow_x = 'auto'
        all_btn_panel.layout.width = '100%'
        all_btn_panel.layout.display = 'flex'
        all_btn_panel.layout.flex_flow = 'wrap'
        return all_btn_panel

    def update_values(self, data, show_apply):
        unique_vals = self._get_unique_vals(data)
        self._make_buttons(unique_vals, show_apply)
        
    def read_values(self):
        """ make list of selected button descriptions """
        selected_vals = []
        for btn in self.btns:
            if btn.value == True:
                selected_vals.append(btn.description)
        return selected_vals
    
    
    # **************************************************************************
    #
    #      Update / create buttons
    #
    # **************************************************************************
    
    def _get_unique_vals(self, data):
        """ Function to take a dataframe series, get unique values, for each 
        string we create a button in the accordion"""
        
        if isinstance(data, pd.Series):
            data = data.unique().tolist()
        
        has_none = False
        has_nan = False
            
        if None in data:
            data.remove(None)
            has_none = True
            
        if np.nan in data:
            data.remove(np.nan)
            has_nan = True     
        
        data = sorted(data)
        if has_none:
            data = data + [None]
            
        if has_nan:
            data = data + [np.nan]
            
        return data

    def _make_buttons(self, data, show_apply):
        """
        data: contains the list of descriptions for the buttons
        """

        all_btn = []

        # Buttons to toggle all/none values
        toggle_all_btn = Button(description = 'Todos', button_style = 'info')
        toggle_non_btn = Button(description = 'Ninguno', button_style = 'info')
        
        toggle_all_btn.layout.width = '100%'
        toggle_non_btn.layout.width = '100%'
        toggle_all_panel = HBox([toggle_all_btn, toggle_non_btn],  
                                 layout = Layout(width='100%'))
        all_btn.append(toggle_all_panel)
        toggle_all_btn.on_click(self._toggle_all_buttons)
        toggle_non_btn.on_click(self._toggle_all_buttons)
        
        # make buttons in the accordion
        self.btns = [] # to reset
        for d in data:
            btn = ToggleButton(description = str(d), value = True)
            btn.layout.width = self.btn_size
            btn.layout.margin = self.btn_margin
            btn.observe(self._button_selected)
            all_btn.append(btn)
            self.btns.append(btn) # we add it to this list, so we can later read the state of each button
            
        # Button to apply changes
        if show_apply == True:
            apply_btn = Button(description = 'Aplicar', button_style = 'warning')
            apply_btn.on_click(self.func)
            btn_panel = HBox([apply_btn], 
                             layout = Layout(width='100%', 
                             justify_content = 'center'))
            all_btn.append(btn_panel)
        
        # Pack
        self.panel.children = all_btn
        
    # **************************************************************************
    #
    #      Events
    #
    # **************************************************************************

    def _toggle_all_buttons(self, btn_caller = None):
        if btn_caller.description == 'Todos':
            button_val = True
        else:
            button_val = False
        self._toggle_observe(True)
        for btn in self.btns:
            btn.value = button_val                 
        self._toggle_observe(False)
        
    def _button_selected(self, tgt = None):
        if tgt['type'] == 'change' and tgt['name'] == 'value':
            btn_state = tgt['owner'].value
            if self._all_btn_selected(btn_state) :
                self._toggle_observe(True) # disable observe to avoid infinite loop
                for btn in self.btns:
                    btn.value = False
                tgt['owner'].value = True
                self._toggle_observe(False) # enable observe again
            
            
    # **************************************************************************
    #
    #      Button behaviors
    #
    # **************************************************************************
    
    def _all_btn_selected(self, btn_state):
        c = 0
        for btn in self.btns:
            if btn.value == True:
                c = c + 1
        if (c == len(self.btns) - 1) and btn_state == False:
            return True
        else:
            return False
    
    def _toggle_observe(self, off):
        if off ==  True:
            for btn in self.btns:
                btn.unobserve_all()
        else:
            for btn in self.btns:
                btn.observe(self._button_selected)